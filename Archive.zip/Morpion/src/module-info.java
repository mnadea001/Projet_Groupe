/**
 * 
 */
/**
 * @author mathi
 *
 */
module Morpion {
	requires org.junit.jupiter.api;
}